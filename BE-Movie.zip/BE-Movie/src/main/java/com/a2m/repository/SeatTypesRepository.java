package com.a2m.repository;

import com.a2m.entities.SeatTypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatTypesRepository extends JpaRepository<SeatTypes, Integer> {
}
