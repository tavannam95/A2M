package com.a2m.repository;

import com.a2m.entities.Nationals;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NationalsRepository extends JpaRepository<Nationals,Integer> {
}
