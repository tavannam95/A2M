package com.a2m.service;

import com.a2m.entities.SeatTypes;

public interface SeatTypeService {
}
