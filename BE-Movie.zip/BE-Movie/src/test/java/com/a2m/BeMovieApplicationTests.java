package com.a2m;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
